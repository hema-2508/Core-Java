public interface MegaInterface {
    // 10 abstract
    void abstractMethod1();
    void abstractMethod2();
    void abstractMethod3();
    void abstractMethod4();
    void abstractMethod5();
    void abstractMethod6();
    void abstractMethod7();
    void abstractMethod8();
    void abstractMethod9();
    void abstractMethod10();

    // 10 default
    default void defaultMethod1() { System.out.println("Default1"); }
    default void defaultMethod2() { System.out.println("Default2"); }
    default void defaultMethod3() { System.out.println("Default3"); }
    default void defaultMethod4() { System.out.println("Default4"); }
    default void defaultMethod5() { System.out.println("Default5"); }
    default void defaultMethod6() { System.out.println("Default6"); }
    default void defaultMethod7() { System.out.println("Default7"); }
    default void defaultMethod8() { System.out.println("Default8"); }
    default void defaultMethod9() { System.out.println("Default9"); }
    default void defaultMethod10() { System.out.println("Default10"); }

    // 10 static
    static void staticMethod1() { System.out.println("Static1"); }
    static void staticMethod2() { System.out.println("Static2"); }
    static void staticMethod3() { System.out.println("Static3"); }
    static void staticMethod4() { System.out.println("Static4"); }
    static void staticMethod5() { System.out.println("Static5"); }
    static void staticMethod6() { System.out.println("Static6"); }
    static void staticMethod7() { System.out.println("Static7"); }
    static void staticMethod8() { System.out.println("Static8"); }
    static void staticMethod9() { System.out.println("Static9"); }
    static void staticMethod10() { System.out.println("Static10"); }
}