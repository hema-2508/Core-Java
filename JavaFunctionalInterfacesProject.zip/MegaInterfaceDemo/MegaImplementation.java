
public class MegaImplementation implements MegaInterface {
    public void method1() { System.out.println("Implemented method1"); }
    public void method2() { System.out.println("Implemented method2"); }
    public void method3() { System.out.println("Implemented method3"); }
    public void method4() { System.out.println("Implemented method4"); }
    public void method5() { System.out.println("Implemented method5"); }
    public void method6() { System.out.println("Implemented method6"); }
    public void method7() { System.out.println("Implemented method7"); }
    public void method8() { System.out.println("Implemented method8"); }
    public void method9() { System.out.println("Implemented method9"); }
    public void method10() { System.out.println("Implemented method10"); }
}
