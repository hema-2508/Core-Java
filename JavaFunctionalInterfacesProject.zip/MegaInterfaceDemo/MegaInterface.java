
public interface MegaInterface {
    void method1();
    void method2();
    void method3();
    void method4();
    void method5();
    void method6();
    void method7();
    void method8();
    void method9();
    void method10();

    default void defaultMethod1() { System.out.println("Default Method 1"); }
    default void defaultMethod2() { System.out.println("Default Method 2"); }
    default void defaultMethod3() { System.out.println("Default Method 3"); }
    default void defaultMethod4() { System.out.println("Default Method 4"); }
    default void defaultMethod5() { System.out.println("Default Method 5"); }
    default void defaultMethod6() { System.out.println("Default Method 6"); }
    default void defaultMethod7() { System.out.println("Default Method 7"); }
    default void defaultMethod8() { System.out.println("Default Method 8"); }
    default void defaultMethod9() { System.out.println("Default Method 9"); }
    default void defaultMethod10() { System.out.println("Default Method 10"); }

    static void staticMethod1() { System.out.println("Static Method 1"); }
    static void staticMethod2() { System.out.println("Static Method 2"); }
    static void staticMethod3() { System.out.println("Static Method 3"); }
    static void staticMethod4() { System.out.println("Static Method 4"); }
    static void staticMethod5() { System.out.println("Static Method 5"); }
    static void staticMethod6() { System.out.println("Static Method 6"); }
    static void staticMethod7() { System.out.println("Static Method 7"); }
    static void staticMethod8() { System.out.println("Static Method 8"); }
    static void staticMethod9() { System.out.println("Static Method 9"); }
    static void staticMethod10() { System.out.println("Static Method 10"); }
}
