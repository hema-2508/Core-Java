
public class RunnerClass {
    public static void main(String[] args) {
        MegaImplementation obj = new MegaImplementation();
        obj.method1(); obj.method2(); obj.method3(); obj.method4(); obj.method5();
        obj.method6(); obj.method7(); obj.method8(); obj.method9(); obj.method10();
        obj.defaultMethod1(); obj.defaultMethod2(); obj.defaultMethod3(); obj.defaultMethod4(); obj.defaultMethod5();
        obj.defaultMethod6(); obj.defaultMethod7(); obj.defaultMethod8(); obj.defaultMethod9(); obj.defaultMethod10();
        MegaInterface.staticMethod1(); MegaInterface.staticMethod2(); MegaInterface.staticMethod3(); MegaInterface.staticMethod4(); MegaInterface.staticMethod5();
        MegaInterface.staticMethod6(); MegaInterface.staticMethod7(); MegaInterface.staticMethod8(); MegaInterface.staticMethod9(); MegaInterface.staticMethod10();
    }
}
